﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zamokServ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //timer1.Start();
            try
            {
                comboBox1.DataSource = SerialPort.GetPortNames();
                serialPort1.Close();
                serialPort1.PortName = comboBox1.SelectedItem.ToString();
                serialPort1.Open();
                // File.Copy(wrk, backup1, true);
            }
            catch (Exception) { }
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.RowHeadersVisible = false;
            notifyIcon1.Visible = false;
        }

        string wrk = Application.StartupPath + "\\zamokDB.mdb";
        // string backup2 = "C:\\zamokDB.mdb";
        string backup1 = "D:\\zamokDB.mdb";
        string adminCard = "";
        string vhod = "";
        private void Form1_Load(object sender, EventArgs e)
        {

            this.historyTableAdapter.Fill(this.histDataSet.history);


            this.usersDBTableAdapter.Fill(this.usersDataSet.usersDB);

            asyncRead();

            adminCard = new WebClient().DownloadString("https://drive.google.com/uc?export=download&id=0B1PRhPmv7AwwdGlsV05pc1pFQ0k");

            dataGridView1.Columns[4].Visible = false;
            dataGridView1.Columns[5].Visible = false;
            visibility(false);
        }




        public void visibility(bool vis)
        {
            textBox2.Visible = vis;
            textBox3.Visible = vis;
            textBox4.Visible = vis;
            textBox5.Visible = vis;
            button1.Visible = vis;
            button3.Visible = vis;
            label3.Visible = vis;
            label4.Visible = vis;
            label5.Visible = vis;
            label7.Visible = vis;
            button4.Visible = vis;
            if (vis == true)
            {
                button2.Location = new Point(256, 446);

                button2.Size = new Size(161, 108);
                return;
            }
            else if (vis == false)
            {
                button2.Location = new Point(12, 446);

                button2.Size = new Size(405, 108);
                return;
            }

        }


        private void button1_Click_1(object sender, EventArgs e)
        {

            usersDataSet.usersDB.Rows.Add();
            usersDataSet.usersDB.Rows[usersDataSet.usersDB.Rows.Count - 1][0] = textBox3.Text;
            usersDataSet.usersDB.Rows[usersDataSet.usersDB.Rows.Count - 1][1] = textBox2.Text;
            usersDataSet.usersDB.Rows[usersDataSet.usersDB.Rows.Count - 1][2] = textBox5.Text;
            usersDataSet.usersDB.Rows[usersDataSet.usersDB.Rows.Count - 1][3] = textBox4.Text;
            usersDataSet.usersDB.Rows[usersDataSet.usersDB.Rows.Count - 1][4] = usersDataSet.usersDB.Count;
            saveUS();
            addToHist(true, "Добавлен новый пользователь:" + textBox2.Text);
            //File.Copy(wrk, backup1, true);
            // File.Copy(wrk, backup2, true);
        }

        public void saveUS()
        {
            usersDBTableAdapter.Update(usersDataSet.usersDB);
            usersDataSet.AcceptChanges();
            usersDBTableAdapter.Fill(this.usersDataSet.usersDB);
            //  historyTableAdapter.Update(historyDataSet.history);
            // historyDataSet.AcceptChanges();
        }

        public void saveHist()
        {
            historyTableAdapter.Update(histDataSet.history);
            histDataSet.AcceptChanges();
            historyTableAdapter.Fill(histDataSet.history);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            usersDBTableAdapter.Fill(this.usersDataSet.usersDB);
            this.historyTableAdapter.Fill(this.histDataSet.history);



        }
        string login = "";
        string pass = "";
        string uuid = "";
        string cache = "";

        // string adminCard = "23351217172";
        string tag;
        public string cardNo;
        string permit;
        int doors = 1;//кол-во дверей

        string kek = "";
        bool flag = false;
        bool flag1 = false;
        public void addToHist(bool res, string door)
        {
            try
            {
                //histDataSet.historyRow hist = histDataSet.history.FindByNum(histDataSet.history.Rows.Count);
                //textBox1.Text = hist.ToString();
                histDataSet.history.Rows.Add();
                //  histDataSet.history.Rows[histDataSet.history.Rows.Count - 1][0] = histDataSet.history.Rows.Count;
                histDataSet.history.Rows[histDataSet.history.Rows.Count - 1][1] = cardNo;
                histDataSet.history.Rows[histDataSet.history.Rows.Count - 1][2] = DateTime.Now;
                histDataSet.history.Rows[histDataSet.history.Rows.Count - 1][3] = door;
                saveHist();
            }
            catch (Exception e) { MessageBox.Show(e.ToString()); }
            //if (res == true)
            //{
            //    MessageBox.Show("Разрешено");
            //    //save();

            //}
            //else { }
        }
        public void solver(string dataIn)
        {
            // dataIn = recv;
            textBox1.Text = dataIn;
            //  Data.Value = dataIn;

            // MessageBox.Show(dataIn);


            try
            {
                //  if (dataIn == "") { MessageBox.Show("ydalil"); }
                //  if (dataIn != "") { kek = dataIn; MessageBox.Show(dataIn); }

                //label1.Text = dataIn;
                //MessageBox.Show(dataIn);

                string[] dataOut;
                dataOut = dataIn.Split(new char[] { '#' });
                tag = dataOut[0];
                //label1.Text += dataOut;
                // label1.Text = dataIn;
                //if (tag != "") { label1.Text=tag; }               tag = dataOut[0];
                cardNo = dataOut[1];
                textBox2.Text = cardNo;
                if (tag.Contains("G"))//add new card
                {

                    if (cardNo == adminCard)
                    {
                        visibility(true);
                        //  dataGridView1.Columns[4].Visible = true; dataGridView1.Columns[5].Visible = true;
                        addToHist(true, "admin");
                    }






                }

                int m = 1;
                for (int n = 1; n <= doors; n++)
                {
                    if (tag.Contains("D" + doors))
                    {
                        for (int i = 0; i < usersDataSet.usersDB.Rows.Count; i++)
                        {


                            //if (cardNo == usersDataSet.usersDB.Rows[i][2].ToString())
                            //  if ( String.Compare(cardNo, usersDataSet.usersDB.Rows[i][2].ToString())==0) 

                            if (object.Equals(cardNo, usersDataSet.usersDB.Rows[i][1].ToString()) == true)
                            {
                                permit = "yes";
                                flag = false;
                                // addToHist(true,tag);
                                label6.Text = "OK";
                                break;
                            }
                            else
                            {
                                permit = "no";
                                flag = true;
                                label6.Text = "NOT OK";
                            }

                        }
                        cache = 'S' + tag + '#' + permit;
                        serialPort1.Write(cache);
                        if (flag == true) { addToHist(false, tag + " " + permit); } else { addToHist(true, tag + " " + permit); }

                    }
                }

                if (tag.Contains("D0"))
                {
                    for (int i = 0; i < usersDataSet.usersDB.Rows.Count; i++)
                    {

                        if (pass == usersDataSet.usersDB.Rows[i][5].ToString() && cardNo == usersDataSet.usersDB.Rows[i][3].ToString())
                        {
                            permit = "yes";
                            flag1 = false;
                            addToHist(true, tag);

                        }

                        else if (pass != usersDataSet.usersDB.Rows[i][5].ToString() && cardNo == usersDataSet.usersDB.Rows[i][3].ToString())
                        {
                            permit = "no";
                            flag1 = true;

                        }
                        else if (pass == usersDataSet.usersDB.Rows[i][5].ToString() && cardNo != usersDataSet.usersDB.Rows[i][3].ToString())
                        {
                            permit = "no";
                            flag1 = true;

                        }
                    }
                    cache = 'S' + tag + '#' + permit;
                    if (flag1 == true) { addToHist(false, tag + " " + permit); } else { addToHist(true, tag + " " + permit); }
                    serialPort1.Write(cache);
                }

                //cache ='S'+tag+ permit;
                //serialPort1.Write(cache); 
                //if (dataIn != "") { MessageBox.Show(dataIn); }

            }
            catch (Exception)
            {

            }

        }

        public string data;

        public string param;

        public delegate void AddTextDelegate();

        public Task<string> DataRd()
        {

            return Task.Run(() =>
            {
                try
                {
                    data = serialPort1.ReadLine();
                    // if (data != "") { MessageBox.Show(data); }
                    //solver(data);
                    SetTextSafe(data);

                }

                catch (Exception)
                {
                    // MessageBox.Show(es.ToString());
                }

                return data;
            });

        }
        // string kek;
        public async void doRead()
        {

            while (true)
            {
                solver(recv);

                // recv = serialPort1.ReadLine();
                // solver(data);
                //solver(dataCOM.Text);
                Application.DoEvents();

                param = await DataRd();
            }
        }

        void SetTextSafe(string newText)
        {

            BeginInvoke(new Action<string>((s) => recv = s), newText);
            Data.Value = recv;

            //  BeginInvoke(new Action<string>((s) => dataCOM.Text = s), newText);
            //solver(recv);
            // if (recv != "") { solver(recv); }// MessageBox.Show(recv); }


        }
        public void asyncRead() { BeginInvoke(new AddTextDelegate(doRead)); }







        private void button3_Click(object sender, EventArgs e)
        {
            //    MessageBoxButtons buttons = MessageBoxButtons.OKCancel;
            //    DialogResult result;
            //    result = MessageBox.Show("Вы уверены, что хотите безвозвратно удалить историю посещений?", "Вы уверены", buttons);
            //    if (result == DialogResult.OK)
            //    {
            //        while (historyDataSet.history.Rows.Count > 0)
            //        {
            //            historyDataSet.history.Clear(); Application.DoEvents();
            //        }
            //        //  
            //        historyTableAdapter.Update(historyDataSet.history);

            //    }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // comboBox1.Items.Clear();
            comboBox1.DataSource = SerialPort.GetPortNames();
            serialPort1.Close();
            serialPort1.PortName = comboBox1.SelectedItem.ToString();
            serialPort1.Open();
        }
        string recv;
        private void timer1_Tick(object sender, EventArgs e) { }


        private void button2_Click_2(object sender, EventArgs e)
        {
            openHistory addN = new openHistory();
            addN.StartPosition = FormStartPosition.CenterScreen;
            addN.Show(this);
        }
        bool flagPW;
        private void button3_Click_1(object sender, EventArgs e)
        {

            if (flagPW == true) { dataGridView1.Columns[4].Visible = true; dataGridView1.Columns[5].Visible = true; flagPW = false; }
            else { dataGridView1.Columns[4].Visible = false; dataGridView1.Columns[5].Visible = false; flagPW = true; }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            visibility(false);
        }
        string kasha = "copy \"" + Application.StartupPath + "\\zamokServ_new.exe\"" + "\"" + Application.StartupPath + "\\zamokServ.exe\"";
        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                // string ver = new WebClient().DownloadString("https://drive.google.com/uc?export=download&id=0B1PRhPmv7AwwZFFDM2VzYXJ3cFU");
                new WebClient().DownloadFile("https://drive.google.com/uc?export=download&id=0B1PRhPmv7AwweldpMTduQm9CVEk", Application.StartupPath + "\\update.bat");


                new WebClient().DownloadFile("https://drive.google.com/uc?export=download&id=0B1PRhPmv7AwwbFBqNjNBLTlKMjQ", Application.StartupPath + "\\zamokServ_new.exe");

                ProcessStartInfo upd = new ProcessStartInfo("cmd.exe");

                Process.Start(Application.StartupPath + "\\update.bat");

                this.Close();





            }

            catch (Exception) { MessageBox.Show("В процесі оновлення сталась помилка\nзверніться до розробника", "Сталась помилка"); }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        DataRow[] foundRow;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int numDel;
            if (e.ColumnIndex == 5)
            {

                numDel = int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString());

                usersDataSet.usersDBRow usToDel = usersDataSet.usersDB.FindByNCust(numDel);
                textBox1.Text = usToDel.ToString();
                //DataRow[] result = usersDataSet.usersDB.Select("SELECT * FROM usersDB WHERE NCust=" + numDel);

                usersDataSet.usersDB.Rows[dataGridView1.CurrentRow.Index].Delete();
                usersDBTableAdapter.Update(usersDataSet.usersDB);
                usersDataSet.usersDB.AcceptChanges();
                addToHist(true, "Картку видалено:"+ dataGridView1.CurrentRow.Cells[3].Value.ToString() +" DT:"+ DateTime.Now);



            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.usersDBTableAdapter.Fill(this.usersDataSet.usersDB);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            File.Copy(wrk, backup1, true);
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            this.usersDBTableAdapter.Fill(this.usersDataSet.usersDB);
        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            // histDataSet.historyRow hist = histDataSet.history.FindByNum(histDataSet.history.Rows.Count);

        }

        private void createNewAdminToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://vk.com/monteshot");
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Normal;
                this.ShowInTaskbar = true;
                notifyIcon1.Visible = false;
            }
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.ShowInTaskbar = false;
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Программу згорнуто";
                notifyIcon1.BalloonTipText = "Програма поміщена в трей, але продовжить роботу";
                notifyIcon1.ShowBalloonTip(7);
            }
        }
    }
}
