﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zamokServ
{
    class Data
    {


        public static string Value { get; set; }

    }

}
