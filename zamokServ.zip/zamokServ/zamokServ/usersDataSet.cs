﻿namespace zamokServ
{


    partial class usersDataSet
    {
    }
}

namespace zamokServ.usersDataSetTableAdapters {
    
    
    public partial class usersDBTableAdapter {
    }
}
