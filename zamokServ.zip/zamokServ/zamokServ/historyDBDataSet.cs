﻿namespace zamokServ
{
}

namespace zamokServ
{


    public partial class historyDBDataSet
    {
    }
}
namespace zamokServ {
    
    
    public partial class historyDBDataSet {
    }
}
